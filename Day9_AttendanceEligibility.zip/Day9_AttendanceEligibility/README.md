# Day9_AttendanceEligibility
**Student Name:** CH. JAYA NAGA VARDHAN  
**Application Number:** AP25110090156  
**Challenge:** Day 9 - Attendance Eligibility Calculator

## Build Commands

### Linux/macOS:
```bash
mkdir -p build
gcc -std=c11 -Wall -Wextra -O2 main.c -o build/program
```

### Windows (MinGW):
```bash
mkdir build
gcc -std=c11 -Wall -Wextra -O2 main.c -o build/program.exe
```

## Run Commands

### Linux/macOS:
```bash
./build/program
```

### Windows:
```bash
build\program.exe
```
